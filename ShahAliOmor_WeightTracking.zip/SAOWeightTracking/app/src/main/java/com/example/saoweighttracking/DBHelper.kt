package com.example.saoweighttracking

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Bump DB version to 2 to add goal_weight and alert_phone
class DBHelper(context: Context) : SQLiteOpenHelper(context, "weightapp.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE users(
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                goal_weight REAL,
                alert_phone TEXT
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE weights(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                date TEXT NOT NULL,
                weight REAL NOT NULL,
                UNIQUE(username, date) ON CONFLICT REPLACE,
                FOREIGN KEY(username) REFERENCES users(username)
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Migrate without dropping data
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE users ADD COLUMN goal_weight REAL")
            db.execSQL("ALTER TABLE users ADD COLUMN alert_phone TEXT")
        }
        // future upgrades can be handled here
    }

    // ----- USERS -----
    fun createUser(username: String, password: String): Boolean {
        val cv = ContentValues().apply {
            put("username", username.trim())
            put("password", password)
        }
        return writableDatabase.insert("users", null, cv) > 0
    }

    fun userExists(username: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT 1 FROM users WHERE username=? LIMIT 1",
            arrayOf(username.trim())
        ).use { c -> return c.moveToFirst() }
    }

    fun validateUser(username: String, password: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT 1 FROM users WHERE username=? AND password=? LIMIT 1",
            arrayOf(username.trim(), password)
        ).use { c -> return c.moveToFirst() }
    }

    fun setGoal(username: String, goal: Float?) {
        val cv = ContentValues().apply {
            if (goal == null) putNull("goal_weight") else put("goal_weight", goal)
        }
        writableDatabase.update("users", cv, "username=?", arrayOf(username))
    }

    fun getGoal(username: String): Float? {
        readableDatabase.rawQuery(
            "SELECT goal_weight FROM users WHERE username=? LIMIT 1",
            arrayOf(username)
        ).use { c ->
            return if (c.moveToFirst() && !c.isNull(0)) c.getFloat(0) else null
        }
    }

    fun setAlertPhone(username: String, phone: String?) {
        val cv = ContentValues().apply {
            if (phone.isNullOrBlank()) putNull("alert_phone") else put("alert_phone", phone)
        }
        writableDatabase.update("users", cv, "username=?", arrayOf(username))
    }

    fun getAlertPhone(username: String): String? {
        readableDatabase.rawQuery(
            "SELECT alert_phone FROM users WHERE username=? LIMIT 1",
            arrayOf(username)
        ).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    // ----- WEIGHTS -----
    fun upsertWeight(username: String, date: String, weight: Float): Long {
        val cv = ContentValues().apply {
            put("username", username)
            put("date", date)
            put("weight", weight)
        }
        return writableDatabase.insertWithOnConflict(
            "weights", null, cv, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun deleteWeight(username: String, date: String): Int {
        return writableDatabase.delete("weights", "username=? AND date=?", arrayOf(username, date))
    }

    fun listWeights(username: String): MutableList<WeightEntry> {
        val out = mutableListOf<WeightEntry>()
        readableDatabase.rawQuery(
            "SELECT date, weight FROM weights WHERE username=? ORDER BY date DESC",
            arrayOf(username)
        ).use { c ->
            while (c.moveToNext()) {
                val date = c.getString(0)
                val weight = c.getFloat(1)
                out.add(WeightEntry(date, "%.1f kg".format(weight)))
            }
        }
        return out
    }
}
