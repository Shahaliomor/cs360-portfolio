package com.example.saoweighttracking

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = DBHelper(this)

        val usernameInput = findViewById<TextInputEditText>(R.id.usernameInput)
        val passwordInput = findViewById<TextInputEditText>(R.id.passwordInput)

        findViewById<MaterialButton>(R.id.signInBtn).setOnClickListener {
            val u = usernameInput.text?.toString()?.trim().orEmpty()
            val p = passwordInput.text?.toString().orEmpty()
            if (u.isBlank() || p.isBlank()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!db.userExists(u)) {
                Toast.makeText(this, "User doesn't exist. Please create account.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (db.validateUser(u, p)) {
                saveActiveUser(u)
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Incorrect password.", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<MaterialButton>(R.id.createAccountBtn).setOnClickListener {
            val u = usernameInput.text?.toString()?.trim().orEmpty()
            val p = passwordInput.text?.toString().orEmpty()
            if (u.isBlank() || p.isBlank()) {
                Toast.makeText(this, "Choose a username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val ok = try { db.createUser(u, p) } catch (_: Exception) { false }
            if (ok) {
                saveActiveUser(u)
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveActiveUser(username: String) {
        getSharedPreferences("app", MODE_PRIVATE).edit()
            .putString("active_user", username)
            .apply()
    }
}
