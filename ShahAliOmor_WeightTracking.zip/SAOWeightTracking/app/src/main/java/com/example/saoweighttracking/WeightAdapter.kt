package com.example.saoweighttracking

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeightAdapter(
    private val items: MutableList<WeightEntry>,
    private val listener: OnEntryAction
) : RecyclerView.Adapter<WeightAdapter.VH>() {

    interface OnEntryAction { fun onDelete(pos: Int); fun onEdit(pos: Int) }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvWeight: TextView = view.findViewById(R.id.tvWeight)
        val editBtn: ImageButton = view.findViewById(R.id.editBtn)
        val deleteBtn: ImageButton = view.findViewById(R.id.deleteBtn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_weight, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.tvDate.text = e.date
        holder.tvWeight.text = e.weight

        holder.editBtn.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) listener.onEdit(pos)
        }
        holder.deleteBtn.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) listener.onDelete(pos)
        }
    }
}
