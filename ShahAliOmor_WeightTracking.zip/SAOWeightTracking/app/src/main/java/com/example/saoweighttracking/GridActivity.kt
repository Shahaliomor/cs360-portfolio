package com.example.saoweighttracking

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.DatePicker
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.time.LocalDate

class GridActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_grid)

        // Always open the dialog when this screen appears
        showDialog()

        // Keep the button as a way to reopen if they cancel the dialog
        findViewById<MaterialButton>(R.id.addBtn).setOnClickListener { showDialog() }
    }

    private fun showDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_entry, null)
        val dateInput = dialogView.findViewById<TextInputEditText>(R.id.inputDate)
        val weightInput = dialogView.findViewById<TextInputEditText>(R.id.inputWeight)

        val editDate = intent.getStringExtra("editDate")
        val editWeight = intent.getStringExtra("editWeight")
        val isEdit = editDate != null && editWeight != null

        if (isEdit) {
            dateInput.setText(editDate)
            weightInput.setText(editWeight.filter { it.isDigit() || it == '.' })
            // Optional: lock date when editing so only the value changes
            // dateInput.isEnabled = false
        } else {
            dateInput.text?.clear()
        }

        dateInput.setOnClickListener {
            val today = LocalDate.now()
            DatePickerDialog(this,
                { _: DatePicker, y, m, d ->
                    dateInput.setText("%04d-%02d-%02d".format(y, m + 1, d))
                }, today.year, today.monthValue - 1, today.dayOfMonth
            ).show()
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(if (isEdit) "Edit Weight Entry" else "Add Weight Entry")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val date = dateInput.text.toString().trim()
                val weight = weightInput.text.toString().trim()
                if (date.isNotEmpty() && weight.isNotEmpty()) {
                    Intent().apply {
                        putExtra("date", date)
                        putExtra("weight", "$weight kg")
                        setResult(RESULT_OK, this)
                    }
                    finish()
                } else {
                    MaterialAlertDialogBuilder(this)
                        .setMessage("Enter both date and weight")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            .setNegativeButton("Cancel") { _, _ ->
                // If user cancels and this was launched just to edit/add, finish so we go back
                if (isTaskRoot.not()) finish()
            }
            .show()
    }
}
