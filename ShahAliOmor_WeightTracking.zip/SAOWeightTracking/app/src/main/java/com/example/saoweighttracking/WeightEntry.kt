package com.example.saoweighttracking
data class WeightEntry(val date: String, var weight: String)
