package com.example.saoweighttracking

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.SmsManager
import android.text.InputType
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class HomeActivity : AppCompatActivity(), WeightAdapter.OnEntryAction {

    private lateinit var db: DBHelper
    private lateinit var adapter: WeightAdapter
    private val history = mutableListOf<WeightEntry>()
    private var goalWeight: Float? = null
    private lateinit var activeUser: String

    // ---- Multiple-permission launcher ----
    private val multiPermsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            // Show quick feedback
            val smsGranted = result[Manifest.permission.SEND_SMS] == true ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
            val notifGranted = if (Build.VERSION.SDK_INT >= 33)
                (result[Manifest.permission.POST_NOTIFICATIONS] == true ||
                        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            else true

            if (!smsGranted) {
                // If user chose "Don't ask again", suggest Settings
                if (!shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
                    AlertDialog.Builder(this)
                        .setTitle("Allow SMS permission")
                        .setMessage("To send alerts automatically, allow SMS in App Settings.")
                        .setPositiveButton("Open Settings") { _, _ ->
                            val uri = Uri.fromParts("package", packageName, null)
                            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                        }
                        .setNegativeButton("Later", null)
                        .show()
                } else {
                    Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show()
                }
            }
            if (!notifGranted && Build.VERSION.SDK_INT >= 33) {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show()
            }
        }

    private val entryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                result.data?.let { data ->
                    val date = data.getStringExtra("date") ?: return@let
                    val weightStr = data.getStringExtra("weight") ?: return@let
                    val weightNum = weightStr.filter { it.isDigit() || it == '.' }.toFloatOrNull()

                    if (weightNum != null) {
                        db.upsertWeight(activeUser, date, weightNum)
                        reloadHistory()
                        Toast.makeText(this, "Saved entry for $date", Toast.LENGTH_SHORT).show()
                        updateProgress()
                        if (goalWeight != null && weightNum >= goalWeight!!) {
                            Toast.makeText(this, "🎯 Goal weight reached!", Toast.LENGTH_LONG).show()
                            showGoalNotification()
                            sendGoalSmsOrFallback()
                        }
                    } else {
                        Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        activeUser = getSharedPreferences("app", MODE_PRIVATE).getString("active_user", null)
            ?: run { startActivity(Intent(this, MainActivity::class.java)); finish(); return }

        db = DBHelper(this)

        setupNotificationChannel()

        adapter = WeightAdapter(history, this)
        findViewById<RecyclerView>(R.id.rvHistory).apply {
            layoutManager = LinearLayoutManager(this@HomeActivity)
            adapter = this@HomeActivity.adapter
        }

        findViewById<MaterialButton>(R.id.btnAdd).setOnClickListener {
            entryLauncher.launch(Intent(this, GridActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnLogout).setOnClickListener {
            getSharedPreferences("app", MODE_PRIVATE).edit().remove("active_user").apply()
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            finish()
        }

        findViewById<TextView>(R.id.tvGoal).apply {
            setOnClickListener { showGoalDialog(this) }
        }

        // Load persisted goal/phone & weights
        goalWeight = db.getGoal(activeUser)
        updateGoalLabel(findViewById(R.id.tvGoal))
        reloadHistory()
        updateProgress()

        // ---- Request permissions right after login (first time only) ----
        maybeRequestPermsAfterLogin()
    }

    private fun maybeRequestPermsAfterLogin() {
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        val asked = prefs.getBoolean("asked_perms_after_login_v2", false)

        val toAsk = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            toAsk += Manifest.permission.POST_NOTIFICATIONS
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            toAsk += Manifest.permission.SEND_SMS
        }

        if (!asked && toAsk.isNotEmpty()) {
            // Optional rationale (1-line) to avoid a “cold” dialog
            AlertDialog.Builder(this)
                .setTitle("Allow alerts?")
                .setMessage("We use notifications and (optionally) SMS to alert you when you reach your goal.")
                .setPositiveButton("Continue") { _, _ ->
                    multiPermsLauncher.launch(toAsk.toTypedArray())
                }
                .setNegativeButton("Not now", null)
                .show()
            prefs.edit().putBoolean("asked_perms_after_login_v2", true).apply()
        }
    }

    private fun reloadHistory() {
        history.clear()
        history.addAll(db.listWeights(activeUser))
        adapter.notifyDataSetChanged()
    }

    private fun setupNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "goal_channel", "Goal Notifications", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Notifies when goal is reached" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestPermsIfNeededNow() {
        val toAsk = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            toAsk += Manifest.permission.POST_NOTIFICATIONS
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            toAsk += Manifest.permission.SEND_SMS
        }
        if (toAsk.isNotEmpty()) multiPermsLauncher.launch(toAsk.toTypedArray())
    }

    private fun showGoalNotification() {
        val builder = NotificationCompat.Builder(this, "goal_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("🎯 Goal Achieved!")
            .setContentText("You’ve reached your goal weight 🎉")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
        NotificationManagerCompat.from(this).notify(1001, builder.build())
    }

    private fun sendGoalSmsOrFallback() {
        val phone = db.getAlertPhone(activeUser)
        if (phone.isNullOrBlank()) return
        val body = "🎯 Congrats! You hit your goal weight!"

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    this.getSystemService(SmsManager::class.java)
                } else {
                    SmsManager.getDefault()
                }
                smsManager.sendTextMessage(phone, null, body, null, null)
                Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openSmsAppFallback(phone, body)
            }
        } else {
            openSmsAppFallback(phone, body) // app continues without SMS permission
        }
    }

    private fun openSmsAppFallback(phone: String, body: String) {
        val uri = Uri.parse("smsto:$phone")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply { putExtra("sms_body", body) }
        startActivity(intent)
    }

    private fun showGoalDialog(tv: TextView) {
        val existingGoal = db.getGoal(activeUser)
        val existingPhone = db.getAlertPhone(activeUser)

        val inputGoal = EditText(this).apply {
            hint = "Enter goal weight (kg)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(existingGoal?.let { "%.1f".format(it) } ?: "")
        }
        val inputPhone = EditText(this).apply {
            hint = "Alert phone number (e.g., +1234567890)"
            inputType = InputType.TYPE_CLASS_PHONE
            setText(existingPhone ?: "")
        }

        val container = androidx.appcompat.widget.LinearLayoutCompat(this).apply {
            orientation = androidx.appcompat.widget.LinearLayoutCompat.VERTICAL
            setPadding(32, 16, 32, 0)
            addView(inputGoal)
            addView(inputPhone)
        }

        AlertDialog.Builder(this)
            .setTitle("Set Goal & SMS")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                val g = inputGoal.text.toString().toFloatOrNull()
                val p = inputPhone.text.toString().trim().ifEmpty { null }

                if (g != null) {
                    goalWeight = g
                    db.setGoal(activeUser, g)
                    db.setAlertPhone(activeUser, p)
                    updateGoalLabel(tv)
                    updateProgress()

                    // Ask right after saving goal+phone as well
                    requestPermsIfNeededNow()
                } else {
                    Toast.makeText(this, "Enter a valid number for goal", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateGoalLabel(tv: TextView) {
        tv.text = if (goalWeight != null) {
            getString(R.string.goal_label, "%.1f".format(goalWeight))
        } else {
            getString(R.string.tap_here_to_set_goal)
        }
    }

    private fun updateProgress() {
        val progress = findViewById<ProgressBar>(R.id.progressBar)
        val latest = history.firstOrNull()
            ?.weight?.filter { it.isDigit() || it == '.' }?.toFloatOrNull()
        progress.progress = if (latest != null && goalWeight != null) {
            ((latest / goalWeight!! * 100).coerceAtMost(100f)).toInt()
        } else 0
    }

    override fun onEdit(pos: Int) {
        val entry = history[pos]
        entryLauncher.launch(Intent(this, GridActivity::class.java).apply {
            putExtra("editDate", entry.date)
            putExtra("editWeight", entry.weight)
        })
    }

    override fun onDelete(pos: Int) {
        val entry = history[pos]
        db.deleteWeight(activeUser, entry.date)
        history.removeAt(pos)
        adapter.notifyItemRemoved(pos)
        updateProgress()
        Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show()
    }
}
